import turtle
t = turtle.Turtle()
class UI_Gif():
    def zfx(self):
        print('start draw circle...')
        t.circle(40)
        print('finish draw circle...')

#
#
# a=UI_Gif()
# a.zfx()

